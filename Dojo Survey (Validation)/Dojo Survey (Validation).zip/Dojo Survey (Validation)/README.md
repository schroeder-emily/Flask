Dojo Survey Solution

I wanted to do the checkboxes, but after talking with Kyle, I learned that each check box would be its own session :) I decided not to spend the time, but I UNDERSTAND why and how to do it!